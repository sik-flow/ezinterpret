"""Top-level package for ezinterpret."""

__author__ = """Jeff Herman"""
__email__ = 'jherman1199@gmail.com'
__version__ = '0.1.0'

from .ezinterpret import *
