===========
ezinterpret
===========


.. image:: https://img.shields.io/pypi/v/ezinterpret.svg
        :target: https://pypi.python.org/pypi/ezinterpret

.. image:: https://img.shields.io/travis/sik-flow/ezinterpret.svg
        :target: https://travis-ci.com/sik-flow/ezinterpret

.. image:: https://readthedocs.org/projects/ezinterpret/badge/?version=latest
        :target: https://ezinterpret.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Python library to make interpretting machine learning models easier :) 


* Free software: GNU General Public License v3
* Documentation: https://ezinterpret.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
